import { Component, OnInit } from '@angular/core';
import { SeatService } from '../../services/seat.service';

@Component({
  selector: 'app-ticket-booking',
  templateUrl: './ticket-booking.component.html',
  styleUrls: ['./ticket-booking.component.css']
})
export class TicketBookingComponent implements OnInit {
  title = 'ticket-booking';
  items = [];
  person = 0;
  copytickets: any;
  bookedarray = [];
  copyarray: any;
  data: any;
  showArray = [];
  noofticketsarray = []
  ticketsbooked: any;
  constructor(private seatService: SeatService) {
    for (let i = 1; i < 11; i++) {
      this.noofticketsarray.push(i);
    }
    this.data = sessionStorage.getItem('currentUser');
    if (this.data == null || this.data == undefined) {
      this.seatService.getItems()
        .subscribe((response) => {
          this.items = response;
        });
    }
    else {
      this.copyarray = sessionStorage.getItem('currentUserdata');
      this.ticketsbooked = sessionStorage.getItem('tickets');
      this.copytickets = sessionStorage.getItem('showArray');
      this.showArray = JSON.parse(this.copytickets);
      this.ticketsbooked = JSON.parse(this.ticketsbooked);
      this.person = this.ticketsbooked;
      this.items = JSON.parse(this.data);
      this.bookedarray = JSON.parse(this.copyarray);

    }

  }
  ngOnInit() { }

  // booking seats in grid
  check(event, item) {

    if (this.person == 0) {
      alert("First  select number of tickets you want to book");
    }
    else {

      if (event.status !== "confirmed") {
        if (event.status == "available") {
          event.status = "selected";
          let temp;
          temp = item.rowno + event.col;
          this.bookedarray.push(event.id);
          this.showArray.push({
            id: event.id,
            key: temp
          });

        }
        else {
          event.status = "available";
          this.showArray = this.showArray.filter(o1 => o1.id !== event.id)
          this.bookedarray = this.bookedarray.filter(order => order !== event.id);
        }

        if (this.bookedarray.length > Number(this.person)) {

          this.items.forEach((el, index) => {
            el.row.forEach((pl, index) => {
              if (pl.id == this.bookedarray[0]) {
                pl.status = "available";
              }

            });
          });
          this.bookedarray.splice(0, 1);
          this.showArray.splice(0, 1);
        }
        sessionStorage.setItem('showArray', JSON.stringify(this.showArray));
        sessionStorage.setItem('currentUser', JSON.stringify(this.items));
        sessionStorage.setItem('currentUserdata', JSON.stringify(this.bookedarray));
        sessionStorage.setItem('tickets', JSON.stringify(this.person));
      }
    }
  }
  // save funtion
  submit() {
    if (this.bookedarray.length != this.person) {
      alert("Select the number of Seats that you have entered");
    } else {
      let temparray = [];
      for (let i = 0; i < this.showArray.length; i++) {
        temparray.push(this.showArray[i].key);
      }
      alert("Your tickets" + " " + temparray + " " + "are booked");
      //id of seats thta needed to booked\
      sessionStorage.removeItem('showArray');
      sessionStorage.removeItem('currentUser');
      sessionStorage.removeItem('currentUserdata');
      sessionStorage.removeItem('tickets');

    }
  }

  // no > of tickets thats  need to booked
  selectticket(list) {
    this.person = list;
    this.showArray = [];
    if (this.bookedarray.length > 0) {
      for (let i = 0; i < this.bookedarray.length; i++) {
        this.items.forEach((el, index) => {
          el.row.forEach((pl, index) => {
            if (pl.id == this.bookedarray[i]) {

              pl.status = "available";
            }
          });
        });
      }
    }
    this.bookedarray = [];
  }
}