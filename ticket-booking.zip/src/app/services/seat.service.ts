import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable()
export class SeatService {

  url = 'http://localhost:3000/items';

  constructor(private http: HttpClient) { }



  getItems() {
   return this.http.get(this.url)
   .pipe(
   map((data:any[]) => {
   return data;
   })
   );
   }

}
